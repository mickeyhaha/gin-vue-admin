1. 安装并初始化msyql

2. CREATE DATABASE IF NOT EXISTS gva DEFAULT CHARSET utf8 COLLATE utf8_general_ci;

3. mysql -uroot -p gva < db/dump20120510.sql

4. 将web/dist.zip 解压，放到http服务器根目录

5. 启动server/main.exe

